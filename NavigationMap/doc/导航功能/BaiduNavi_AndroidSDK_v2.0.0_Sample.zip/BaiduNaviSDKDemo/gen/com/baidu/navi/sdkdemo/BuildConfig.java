/** Automatically generated file. DO NOT MODIFY */
package com.baidu.navi.sdkdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}